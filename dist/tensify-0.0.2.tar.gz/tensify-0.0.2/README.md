# Tensify™

An easy to use python package to convert your tenses...


Features : 
1.Super-Simple
2.Easy
3.Minimalistic
4.Super-Fast
5.Open-Source
6.New Concept
7.Trusted
8.Free


Usage :
```
import tensify
tensify.PAST("I get it")
# As simple as that 
```

Output : 
```
I got it
```



Contributors : 
```
1.Dev Shah (Contact : devshah1032@gmail.com)
2.Haard Majmudar (Contact : haardmajmudar2827@gmail.com)
```



License : 
```
MIT License
Copyright (c) 2021 Dev Shah
```